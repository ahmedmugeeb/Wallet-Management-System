#ifndef WALLET_H
#define WALLET_H

typedef struct { // hold values for the date
    int year;
    int month;
    int day;
} Date;

typedef struct { // hold values for transactions
    double amount;
    char category[50];
    char description[100];
    Date date;
} Transaction;

typedef struct {
    Transaction *transactions; // dynamic memory allocation
    int transactionCount; // how many transactions are stored
    int maxTransactions; // maximum limit of transactions
    double balance;
} Wallet;

/* Functions from wallet.c */

void initWallet(Wallet *w, int maxTransactions);
void freeWallet(Wallet *w); // free the values from the heap
void addMoney(Wallet *w); // add money to the wallet
void spendMoney(Wallet *w); // subtract money from the wallet
void showBalance(Wallet *w); // show the money in the wallet
void showHistory(Wallet *w); // show how much money spent and added
void showTransactionsBetweenDates(Wallet *w); // enter two dates and show history between
void saveWalletToFile(Wallet *w, const char *filename); // file handling so when we close the prog the money saved//
void loadWalletFromFile(Wallet *w, const char *filename); // show the money from the previous run
void ensureCapacity(Wallet *w);//check capacity and expand


Date inputDate();
int dateIsBetween(Date x, Date a, Date b);

#endif
