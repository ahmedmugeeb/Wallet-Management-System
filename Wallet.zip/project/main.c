#include <stdio.h>
#include <stdlib.h>
#include "wallet.h"

void printMenu() { // show the menu
    printf("\n=== Wallet Menu ===\n");
    printf("1. Add Money\n");
    printf("2. Spend Money\n");
    printf("3. Check Balance\n");
    printf("4. View Transaction History\n");
    printf("5. View Transactions Between Dates\n");
    printf("6. Exit\n");
    printf("===================\n");
}

int main() {
    Wallet wallet;

    // Load the money from the saved file
    loadWalletFromFile(&wallet, "wallet.dat");

    int running = 1;
    int choice; // asking user to choose

    while (running) {
        printMenu(); // calling the printing function (printing the menu)

        while (scanf("%d", &choice) != 1 || choice < 1 || choice > 6) {
            printf("Invalid input. Enter number from 1 to 6: ");
            while (getchar() != '\n'); // checking for errors
        }

        switch (choice) { // choice result or action
            case 1:
                addMoney(&wallet);
                break;
            case 2:
                spendMoney(&wallet);
                break;
            case 3:
                showBalance(&wallet);
                break;
            case 4:
                showHistory(&wallet);
                break;
            case 5:
                showTransactionsBetweenDates(&wallet);
                break;
            case 6:
                running = 0;
                break;
        }
    }

    // Save wallet to file on exit
    saveWalletToFile(&wallet, "wallet.dat");
    freeWallet(&wallet);

    return 0;
}
