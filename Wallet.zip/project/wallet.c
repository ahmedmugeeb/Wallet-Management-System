#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wallet.h"


void ensureCapacity(Wallet *w);
Date inputDate();

void initWallet(Wallet *w, int initialCapacity) {
    w->balance = 0;
    w->transactionCount = 0;
    w->maxTransactions = initialCapacity;   // small initial size

    w->transactions = malloc(initialCapacity * sizeof(Transaction));
    if (!w->transactions) {
        printf("Memory allocation failed\n");
        exit(1);
    }
}

// free the money from the heap
void freeWallet(Wallet *w) {
    free(w->transactions);
}



// function for adding money
void addMoney(Wallet *w) {

    // Checks wallet capacity first
  ensureCapacity(w);

    double amount;
//repeat until the user gives correct input
    while (1) {
        printf("Enter amount to add: ");
        if (scanf("%lf", &amount) == 1 && amount >= 0) break;
        while (getchar() != '\n');
    }

    w->balance += amount; // add the money to balance

    // local struct
    Transaction t;
    t.amount = amount;
    strcpy(t.category, "Add");
    t.date = inputDate();
    snprintf(t.description, sizeof(t.description), "Added %.2lf", amount);
//snprintf will not write beyond the buffer size( no overflow )
    w->transactions[w->transactionCount++] = t; // stores and increment in counter
}

void spendMoney(Wallet *w) {

    // Check wallet capacity first
    ensureCapacity(w);

    double amount;
    int categoryChoice;
    //const to prevent the modification ( change ) of elements
    const char *categories[5] = {"Food","Transport","Entertainment","Bills","Others"};


    printf("Choose category:\n");
    for (int i = 0; i < 5; i++)
        printf("%d. %s\n", i+1, categories[i]);

    while (1) {
        printf("Enter category number: ");
        if (scanf("%d", &categoryChoice) == 1 && categoryChoice >= 1 && categoryChoice <= 5) break;
        while (getchar() != '\n');
    }

    while (1) {
        printf("Enter amount: ");
        if (scanf("%lf", &amount) == 1 && amount >= 0 && amount <= w->balance) break;
        while (getchar() != '\n');
    }

    w->balance -= amount;

    // the same as add amount but here we are subtracting
    Transaction t;
    t.amount = -amount;
    strcpy(t.category, categories[categoryChoice - 1]); // -1 because we started from 1 while compiler start from 0
    t.date = inputDate();
    snprintf(t.description, sizeof(t.description), "Spent %.2lf on %s", amount, t.category);

    w->transactions[w->transactionCount++] = t;
}

void showBalance(Wallet *w) {
    printf("Current balance: %.2lf\n", w->balance);
}

void showHistory(Wallet *w) {
    if (w->transactionCount == 0) {
        printf("No transactions.\n");
        return;
    }


    for (int i = 0; i < w->transactionCount; i++) {
        Transaction *t = &w->transactions[i]; // pointer to struct
        printf("%d. %.2lf | %s | %04d-%02d-%02d | %s\n",
               i+1, t->amount, t->category,
               t->date.year, t->date.month, t->date.day,
               t->description); // printing all categories and i+1 to make the first element 1
    }
}

Date inputDate() {
    Date d;
    while (1) {
        printf("Enter date (YYYY MM DD): ");
         if (scanf("%d %d %d", &d.year, &d.month, &d.day) == 3 && d.year >0 && d.month> 0 && d.day >0) break;
        while (getchar() != '\n');
    }
    return d;
}

int dateIsBetween(Date x, Date a, Date b) {
    if (x.year < a.year || x.year > b.year) return 0;
    if (x.year == a.year && (x.month < a.month || (x.month == a.month && x.day < a.day))) return 0;
    if (x.year == b.year && (x.month > b.month || (x.month == b.month && x.day > b.day))) return 0;
    return 1;
    // First check year, then month, then day
}

void showTransactionsBetweenDates(Wallet *w) {
    Date start, end;
    printf("Enter start date:\n");
    start = inputDate();
    printf("Enter end date:\n");
    end = inputDate();

    double total = 0;
    printf("\nTransactions in range:\n");

    for (int i = 0; i < w->transactionCount; i++) {
        Transaction *t = &w->transactions[i]; // same as show history
        if (dateIsBetween(t->date, start, end)) {
            printf("%.2lf | %s | %04d-%02d-%02d | %s\n",
                   t->amount, t->category,
                   t->date.year, t->date.month, t->date.day,
                   t->description);
            total += t->amount;
        }
    }

    printf("Total value in range: %.2lf\n", total);
}

void saveWalletToFile(Wallet *w, const char *filename) {
    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        printf("Error: could not open file for writing.\n");
        return;
    }

    fwrite(&w->balance, sizeof(double), 1, fp);
    fwrite(&w->transactionCount, sizeof(int), 1, fp);
    fwrite(&w->maxTransactions, sizeof(int), 1, fp);
    fwrite(w->transactions, sizeof(Transaction), w->transactionCount, fp);

    fclose(fp);
}

void loadWalletFromFile(Wallet *w, const char *filename) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("No wallet file found, starting new wallet.\n");

        initWallet(w, 2);
        return;
    }

    double savedBalance;
    int savedCount, savedMax;

    fread(&savedBalance, sizeof(double), 1, fp);
    fread(&savedCount, sizeof(int), 1, fp);
    fread(&savedMax, sizeof(int), 1, fp);


    initWallet(w, savedMax);

    w->balance = savedBalance;
    w->transactionCount = savedCount;

    fread(w->transactions, sizeof(Transaction), savedCount, fp);

    fclose(fp);
}
void ensureCapacity(Wallet *w) {
    if (w->transactionCount < w->maxTransactions) return;
    int newCapacity = w->maxTransactions + 1;   // double
    Transaction *newsize = realloc(w->transactions, newCapacity * sizeof(Transaction));

    if (!newsize) {
        printf("ERROR: Memory reallocation failed. Cannot expand wallet.\n");
        return;
    }

    w->transactions = newsize;
    w->maxTransactions = newCapacity;

    printf("Wallet expanded, New max transactions = %d\n", newCapacity);
}

